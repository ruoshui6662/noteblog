import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Documentation Site",
  description: "Three-column docs site with sidebar navigation, main content area, table of contents, and code blocks.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
