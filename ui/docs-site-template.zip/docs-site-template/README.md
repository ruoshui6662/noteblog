# Documentation Site / 文档站点

Three-column docs site with sidebar navigation, main content area, table of contents, and code blocks.

A standalone Next.js + Tailwind CSS v4 project exported from
[StyleKit Templates](https://www.stylekit.top/templates).

## Getting started / 快速开始

```bash
pnpm install   # or: npm install / yarn
pnpm dev       # http://localhost:3000
```

## Stack

- Next.js (App Router) + React
- Tailwind CSS v4 (no config file needed)
- lucide-react icons

## License

Free for personal and commercial use. Attribution appreciated but not
required — a link back to stylekit.top helps the project keep going.
